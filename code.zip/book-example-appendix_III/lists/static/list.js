$('input').on('keypress', function () {
    $('.has-error').hide();
});
